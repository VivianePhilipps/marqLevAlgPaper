R_Yir <- function(xir, d, K, knots, ParaTransformY, degree){
  require(splines2)
  current.na.action <- options('na.action')
  options(na.action = "na.pass")
  eps <- 0.0001
  m_i <- d/K
  y00 <- xir; # initialisation de y00 : a revoir
  
  y0 <- y00
  y1 <- - y00
  itr <- 1
  #   while(sqrt(na.omit(sum((y1-y0)^2)))>eps & itr<=2){
  while(itr<=2){
    # from vect to matrix calcul de Hy00 et de Hy00Prim
    mat_y <- VecToMat(y = y0, K = K, m_i = m_i)
    colnames(mat_y)<- paste("y", 1:K, sep = "")
    col <- colnames(mat_y)
    
    mat_Hy0 <- NULL
    mat_Hy0Prim <- NULL
    p <- 1 # indice de parcours du vecteur ParaTransformY
    for(k in 1:K){
      knots_k <- knots[[k]]
      nknots <- length(knots_k)
      if(nknots>2){
        int_knots <- as.vector(as.numeric(knots[[k]][-c(1,nknots)]))
      }else{
        int_knots <- NULL
      }
      
      modISpline <- paste("~ 1 + iSpline(",col[k],",knots=","int_knots",",","degree=", degree,
                          ",", "intercept = T,", "derivs= 0)")
      
      modMSpline <- paste("~ -1 + iSpline(",col[k],",knots=","int_knots",",","degree=", degree,
                          ",", "intercept = T, ", "derivs = 1)")
      
      IsMat <- model.matrix(as.formula(modISpline), data = as.data.frame(mat_y), na.action = na.action)
      MsMat <- model.matrix(as.formula(modMSpline), data = as.data.frame(mat_y), na.action = na.action)
      MsMat <- cbind(rep(0.0, nrow(MsMat)), MsMat)
      nbpara_k <- ncol(IsMat)
      Hy0_k <- IsMat %*% ParaTransformY[p:(p+nbpara_k-1)]
      Hy0Prim_k <- MsMat %*% ParaTransformY[p:(p+nbpara_k-1)]
      p <- p+nbpara_k
      
      mat_Hy0 <- cbind(mat_Hy0, Hy0_k)
      mat_Hy0Prim <- cbind(mat_Hy0Prim, Hy0Prim_k) 
    }
    Hy0 <- vectorise(mat_Hy0)
    Hy0Prim <-vectorise(mat_Hy0Prim)
    
    y1 <- y0 -(Hy0 - xir)/Hy0Prim
    y0 <- y1
    itr <- itr + 1
  }
  #   cat(itr, "\n")
  na.action = current.na.action
  return(y1)
  #   return(xir)
}


R_MC <- function(K, nr, mu, SD, knots, ParaTransformY, degree){
  require(MASS)
  d <- length(mu)
  Xi <- t(mvrnorm(n = nr, mu = mu, Sigma = SD))
  Yi <- matrix(rep(0,length(mu)*nr), ncol = nr)
  for(r in 1:nr){
    Yi[,r] <- R_Yir(xir = Xi[,r], d = d, K = K, knots = knots, ParaTransformY = ParaTransformY, degree = degree)
  }
  return(apply(Yi, MARGIN = 1, FUN = sum)/nr)
  #   return(Xi)
}
