WaldMult <- function( v,beta,pos,matR, value){
  # calcul de la matrice de variance covariance des paramètres====
  # v = vector pour créer la matrice de variance covariance
  m <- length(beta)
  var_cov <- matrix(0,nrow=m,ncol=m)
  var_cov[upper.tri(var_cov,diag=TRUE)] <- v
  var_cov[lower.tri(var_cov,diag=FALSE)] <- t(var_cov)[lower.tri(var_cov,diag=FALSE)]
  
  # On cree la matrice qui recevra les varcov des parametres de pos
  Mat <- matrix(0,nrow=length(pos),ncol=length(pos))
  # Remplissage de Mat sans boucles
  Mat <- matR%*%var_cov[pos,pos]%*%t(matR)
  
  # Wald Multivarie, sans le vecteur contrasts
  Vect <- matR%*%beta[pos]-value
  
  Wald <- t(Vect)%*%solve(Mat)%*%Vect
  
  # Nombre de degre de liberte
  ddl <- length(pos)
  # Pvalue
  p_value <- 1-pchisq(Wald,df=ddl)
  return(p_value)
}

# WaldMult(model$hessian,model$para[1:10],c(1,2),c(0,0))
