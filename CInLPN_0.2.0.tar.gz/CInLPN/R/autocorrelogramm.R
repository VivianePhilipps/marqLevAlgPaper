autocorrelogram <- function(mat_corr, age0, pas, K, color="black", if_legend = FALSE, legend="autocorrelation"){
  cl <- match.call()
  nb.model <- length(mat_corr)
  if(length(color)!=nb.model) stop("nomber of color must egal of number of model")
  if(length(legend)!=nb.model) stop("nomber of legend must egal of number of model")
  tau_i <- sort(unique(as.numeric(colnames(mat_corr[[1]]))))
  tau_i <- age0 + pas*tau_i
  table_corr <- list()
  for( n in 1: nb.model){
    mat <- NULL
#     mat <- as.matrix(mat_corr[[n]][1:K,])
        mat <- as.matrix(mat_corr[[n]][,1:K])
    if(K == 1){table_corr[[n]] <- mat }
    if(K>1){
      table <- NULL
      for(k in 1:K){
        L <- NULL
        for(t in 1: length(tau_i)){
#           L <- rbind(L,mat[k,(K*(t-1)+1):(K*t)])
          L <- rbind(L,t(mat[(K*(t-1)+1):(K*t),k]))
        }
        table <- cbind(table, L)
      }
      table_corr[[n]] <- table
    }
    #colnames
    col_a <-NULL
    col_a1 <- seq(1,K)
    for(k in 1:K){
      col_a<- c(col_a, paste( col_a1[k], col_a1, sep=""))
    }
    col_a <- paste("Rho_", col_a, sep="")
    colnames(table_corr[[n]]) <- col_a
    #rownames
    rownames(table_corr[[n]]) <- tau_i
  }
  #plot====
  par(mfrow = c(1,1))
  #   par(mfrow= c(K,K))
  par(mfrow = c(K,K), lwd = .6, cex = .8, mar=c(4,4,1,1))
  for(k in 1:(K*K)){
    plot(y = table_corr[[1]][,k],x=tau_i, type = "h", ylim = c(-1,1), ylab = col_a[k] , xlab = "Temps", col=color[1], lwd=2)
    abline(h=0, col = 1, lty=2, lwd=0.5)
    axis(1, tau_i, tau_i,1)
    axis(2)
    if(nb.model>1){
      for(n in 2: nb.model){
        lines(y = table_corr[[n]][,k],x=tau_i, type = "h", ylim = c(-1,1), ylab = col_a[k] , xlab = "Temps", col=color[n], lwd=2) 
      }
    }
    if(if_legend ==TRUE){
      legend(x="bottomleft", legend=legend,  bty = "n", cex = .9, lwd = 1.5, col=color) # puts text in the legend
    }
    
  }
#   return(table_corr)
}