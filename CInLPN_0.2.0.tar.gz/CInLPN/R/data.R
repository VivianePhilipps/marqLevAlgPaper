#' simulated data to run an exemple
#'
#' @docType data
#'
#' @usage data(data)
#'
#'@format A datasets of 3584 observations and 7 variables
#'
#' @keywords datasets
#'
#'
#' @examples
#' data(data)
#' head(data)
"data"