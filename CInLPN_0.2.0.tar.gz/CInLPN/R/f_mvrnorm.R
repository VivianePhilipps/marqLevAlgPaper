f_mvrnorm<- function(seed, m, sd){
  require(MASS)
  set.seed(seed)
  
  return(mvrnorm(n=1, mu = m, Sigma = sd))
}
