predict.CInLPN <- function(object,newdata, subject, Time,...)
{
  
  if(missing(object)) stop("The argument object should be specified")
  if(missing(newdata)) stop("The argument newdata should be specified")
  if(missing(subject)) stop("The argument subject should be specified")
  if(missing(Time)) Time <- object$Time
  if(!(Time %in% colnames(newdata))) stop("The variable Time of the model must be a colname of the newdata")
  if (!inherits(object, "CInLPN")) stop("use only with \"CInLPN\" objects")
  if (!all(subject %in% colnames(newdata)))stop("newdata should include the subjects id")
  if (!all(object$preds %in% colnames(newdata))) {
    stop(paste(c("newdata should at least include the following covariates: ","\n",object$preds),collapse=" "))}
  
  if (!all(object$outcomes %in% colnames(newdata))) {
    new_outcomes <- as.data.frame(matrix(data = rep(NA,dim(newdata)[1]*length(object$outcomes)), 
                                         ncol = length(object$outcomes)))
    colnames(new_outcomes) <- object$outcomes
    newdata <- as.data.frame(cbind(newdata,new_outcomes))
  }
  
  if (!inherits(newdata, "data.frame")) stop("newdata should be a data.frame object")
  if(dim(unique(newdata))[1] != dim(newdata)[1]) stop("Some rows are the same in the dataset, Perhaps because of the discretisation step")
  #
  call_formula <- object$formula
  outcomes <- object$outcomes
  K <- length(outcomes)
  if_link <- 0 
  if(!is.null(object$linkstype)) if_link <- 1
  # if(object$conv==1) {
  #   newdata1 <- data.frame(newdata[,c(subject,unlist(object$outcomes, object$preds))])
  # }
  # formatage des donnees
  
  data_F <-DataFormat(data=newdata, subject = subject, fixed_X0.models=as.vector(call_formula[["fixed_X0.models"]]),
                      randoms_X0.models = call_formula[["randoms_X0.models"]], 
                      fixed_DeltaX.models = call_formula[["fixed_DeltaX.models"]], 
                      randoms_DeltaX.models = call_formula[["randoms_DeltaX.models"]], 
                      mod_trans.model = call_formula[["mod_trans.model"]], outcomes = outcomes, 
                      link=object$linkstype, knots = object$knots, nD = object$nD, Time = Time, DeltaT=object$DeltaT)
  
  
  fitted.values <- pred(K = K, nD = object$nD, mapping = object$mapping.to.LP, paras = object$coefficients,
                        m_is= data_F$m_i, Mod_MatrixY = data_F$Mod.MatrixY, df= data_F$df,
                        x0 = data_F$x0, x = data_F$x, z0 = data_F$z0, z = data_F$z, q0 = data_F$q0, q = data_F$q, 
                        nb_paraD = data_F$nb_paraD, if_link = if_link, tau = data_F$tau,
                        tau_is=data_F$tau_is, modA_mat = data_F$modA_mat, DeltaT= object$DeltaT)
  fitted.values <- data.frame(cbind(data_F$id_and_Time,fitted.values))
  fitted.values[is.nan(as.matrix(fitted.values))] <- NA
  col <- NULL
  for(k in 1:K){
    col <- c(col,paste(outcomes[k], c(".tr", ".pM", ".Residu.M", ".pSS", ".Residu.SS"),sep=""))
  }
  colnames(fitted.values) <- c(colnames(data_F$id_and_Time),col)
  return(fitted.values)
}