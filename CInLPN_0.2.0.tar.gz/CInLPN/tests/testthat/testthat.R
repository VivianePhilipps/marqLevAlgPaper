library(testthat)
library(CInLPN)

# data <- load("data/data.rda")
#test_check("CInLPN", {

indexparaFixeUser <- c(1,7)
paraFixeUser <- c(0,1)
paras.ini <- NULL
CInLPN(structural.model = list(fixed.LP0 = ~ 1 + C1 + C2,
                                         fixed.DeltaLP = L1 ~1,
                                         random.DeltaLP = ~ 1,
                                         trans.matrix = ~ 1, delta.time = 1),
                 measurement.model = list(link.functions = list(links = c("linear"),
                                                                knots = list(NULL))),
                 parameters = list(paras.ini = paras.ini, Fixed.para.index = indexparaFixeUser,
                                   Fixed.para.values = paraFixeUser),
                 option = list(parallel = F, nproc = 1, print.info = F, epsa = 1e-3, epsb = 1e-3, epsd = 1e-3,
                               maxiter=200, mekepred = F, MCnr = 1),
                 Time = "time", subject = "numero", data = data)
# }
# )


