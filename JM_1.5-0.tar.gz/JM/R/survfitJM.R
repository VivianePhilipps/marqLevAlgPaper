survfitJM <-
function (object, newdata, ...) {
    UseMethod("survfitJM")
}
